<?php 
namespace App\Models;

use CodeIgniter\Model;

class M_user extends Model
{
	protected $table            = 'users';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = ['user_name', 'user_email', 'user_pass'];

	public function get_data($email, $password)
	{
      return $this->db->table('users')
      ->where(array('user_name' => $email, 'user_pass' => $password))
      ->get()->getRowArray();
	}

	//--------------------------------------------------------------------

}