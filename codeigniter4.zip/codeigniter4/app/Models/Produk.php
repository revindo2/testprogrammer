<?php

namespace App\Models;

use CodeIgniter\Model;

class Produk extends Model
{
    protected $table            = 'produks';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = ['name', 'harga_beli', 'harga_jual', 'stok', 'gambar', 'category'];

    public function getData()
    {
        return $this->db->table('produks')
        ->select('produks.id, produks.name, produks.harga_beli, produks.harga_jual, produks.stok, produks.gambar, category.name_category AS category_name')
         ->join('category','category.id=produks.category')
         ->get()->getResultArray();  
    }


}
