<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;

use App\Models\M_user;

class ProfileController extends BaseController
{
    protected $user;
 
    function __construct()
    {
        $this->user = new M_user();
    }

	public function index()
	{
		return view('profile');
    }
  

}