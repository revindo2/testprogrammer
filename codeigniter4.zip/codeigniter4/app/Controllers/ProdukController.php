<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;
use App\Models\Produk;

class ProdukController extends BaseController
{
    protected $produk;
 
    function __construct()
    {
        $this->produk = new Produk();
    }

    public function all()
    {
        // $data = $this->produk->findAll();
        $data   = $this->produk->getData();
        $total  = $this->produk->countAll();

        echo json_encode([
            'status'    => 'success',
            'rows'      => $data,
            'total'     => $total
        ]);
    }

    public function create()
    {
        return view('produk/create');
    }

    public function add()
    {
        // validation
        $validated = $this->validate([
            'gambar' => [
                'uploaded[gambar]',
                'mime_in[gambar,image/jpg,image/jpeg,image/gif,image/png]',
                'max_size[gambar,4096]',
            ],
            'harga_beli'    => 'required|numeric',
            'name'          => 'required|min_length[3]|max_length[255]|is_unique[produks.name]',
        ]);
 
        if ($validated) {
            $gambar = $this->request->getFile('gambar');

            // ambil data nama random
            $nama_gambar = $gambar->getName();

            // pindahkan file
            $gambar->move(WRITEPATH . '../public/assets/images');

            $this->produk->insert([
                'name'          => $this->request->getPost('name'),
                'harga_beli'    => $this->request->getPost('harga_beli'),
                'harga_jual'    => $this->request->getPost('harga_beli') + ($this->request->getPost('harga_beli') * 0.3),
                'stok'          => $this->request->getPost('stok'),
                'category'      => $this->request->getPost('category'),
                'gambar'        => $nama_gambar,
            ]);

            return redirect('home')->with('success', 'Data Added Successfully');
        }

        return redirect('produk/create')->with('validasi', 'Gagal Insert Validasi Gagal');

    }

    public function edit($id)
    {
        //model initialize
        $postModel = new Produk();

        $data = array(
            'data' => $postModel->find($id)
        );

        return view('produk/edit', $data);
    }

    public function update($id)
    {
        // get file gambar
        $gambar = $this->request->getFile('gambar');

        // ambil data nama random
        $nama_gambar = $gambar->getName();

        // pindahkan file
        $gambar->move(WRITEPATH . '../public/assets/images');

        $this->produk->update($id, [
            'name' => $this->request->getPost('name'),
            'harga_beli' => $this->request->getPost('harga_beli'),
            'harga_jual' => $this->request->getPost('harga_beli'),
            'stok' => $this->request->getPost('stok'),
            'category' => $this->request->getPost('category'),
            'gambar' => $nama_gambar,
        ]);

        return redirect('home')->with('success', 'Data Updated Successfully'); 
    }

    public function delete($id)
    {
        $this->produk->delete($id);

        return redirect('home')->with('success', 'Data Deleted Successfully');
    }
}
