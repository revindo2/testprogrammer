<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;

use App\Models\M_user;

class Login extends BaseController
{
    protected $user;
 
    function __construct()
    {
        $this->user = new M_user();
    }

	public function index()
	{
		return view('user_form');
    }
   
   public function login_action() 
   {
        $username = $this->request->getPost('username');
        $password = $this->request->getPost('password');

        $cek = $this->user->get_data($username, $password);

        if ($cek) {
            if ($cek['user_name'] == $username && $cek['user_pass'] == $password){
                session()->set('username', $cek['user_name']);
                session()->set('password', $cek['user_pass']);
                session()->set('posisi', $cek['posisi']);
                // return redirect('home');
                return redirect()->to(base_url('home'));
            }
        }else{
            session()->setFlashdata('gagal', 'Username / Password salah');
            // return redirect('/');
            return redirect()->to(base_url('/'));
        }
    }

    public function logout() 
    {
        session()->destroy();
        return redirect('/');
    }

	//--------------------------------------------------------------------

}