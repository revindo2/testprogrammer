<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
// $routes->get('/', 'Home::index');
$routes->get('/', 'Login::index');
$routes->get('home', 'Home::index');
$routes->get('produk/all', 'ProdukController::all');
$routes->get('produk/create', 'ProdukController::create');
$routes->add('produk/add', 'ProdukController::add');
$routes->get('produk/search', 'ProdukController::search');
$routes->add('produk/edit/(:segment)', 'ProdukController::edit/$1');
$routes->add('produk/update/(:segment)', 'ProdukController::update/$1');
$routes->get('produk/delete/(:segment)', 'ProdukController::delete/$1');
$routes->add('login/login_action', 'Login::login_action');
$routes->add('logout', 'Login::logout');
$routes->get('profile', 'ProfileController::index');